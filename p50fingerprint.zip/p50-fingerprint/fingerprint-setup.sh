#!/usr/bin/env bash
# ==============================================================================
#  ThinkPad P50 — fingerprint reader setup, start to finish
# ==============================================================================
#  Rebuilds everything needed to get the Validity VFS7500 (138a:0090) working
#  on a fresh CachyOS / Arch install: driver stack, sensor pairing, PAM wiring,
#  and the two non-obvious fixes that make it actually stay working.
#
#  Every step prints WHAT it is about to do and WHY before doing it, and stops
#  for confirmation before anything irreversible.
#
#  USAGE
#      bash fingerprint-setup.sh              # guided run
#      bash fingerprint-setup.sh --dry-run    # print actions, change nothing
#      bash fingerprint-setup.sh --patch-only # re-apply the proto9x patch after
#                                             # an update reverts it
#      bash fingerprint-setup.sh --status     # report current state, change nothing
#
#  RUN AS YOUR NORMAL USER, NOT ROOT. The script calls sudo where it needs to.
#  Running the whole thing under sudo enrolls the fingerprint against root
#  instead of you, which is the single most common way to waste an afternoon.
#
#  BEFORE YOU START
#      Open a root shell on another TTY and leave it there:
#          Ctrl+Alt+F2  ->  log in  ->  sudo -i
#      That is your undo channel if a PAM edit goes wrong.
#
#  WHAT MAKES THIS HARDER THAN IT LOOKS — the three things that bite people:
#    1. Upstream libfprint does NOT support 138a:0090 and never has. You need a
#       patched fork. python-validity, the tool most guides point you at, has
#       had unresolved enrollment bugs on this exact chip since 2021.
#    2. proto9x ships a str/bytes bug that modern fastecdsa rejects, so pairing
#       dies halfway through and leaves the sensor's flash half-written.
#    3. TLP autosuspends the sensor after 2 seconds idle, which makes it fail
#       intermittently forever afterwards in a way that looks like bad hardware.
# ==============================================================================

set -uo pipefail

SENSOR_ID="138a:0090"
AUR=""            # set in step 3; referenced in the wrap-up notes
DRY=0; PATCH_ONLY=0; STATUS_ONLY=0
for a in "$@"; do
  case "$a" in
    --dry-run)    DRY=1 ;;
    --patch-only) PATCH_ONLY=1 ;;
    --status)     STATUS_ONLY=1 ;;
    -h|--help)    sed -n '2,45p' "$0"; exit 0 ;;
    *) echo "unknown flag: $a  (try --help)"; exit 2 ;;
  esac
done

BACKUP_DIR="$HOME/fingerprint-setup-backups/$(date +%Y%m%d-%H%M%S)"
STEP_NO=0

# ------------------------------------------------------------------ output ---
c_r=$'\033[31m'; c_g=$'\033[32m'; c_y=$'\033[33m'; c_b=$'\033[36m'
c_d=$'\033[2m';  c_bold=$'\033[1m'; c_0=$'\033[0m'

ok()   { printf '  %s✔%s %s\n' "$c_g" "$c_0" "$*"; }
bad()  { printf '  %s✘%s %s\n' "$c_r" "$c_0" "$*"; }
warn() { printf '  %s!%s %s\n' "$c_y" "$c_0" "$*"; }
info() { printf '    %s%s%s\n' "$c_d" "$*" "$c_0"; }

step() {
  STEP_NO=$((STEP_NO+1))
  printf '\n%s%s━━ STEP %d — %s%s\n' "$c_b" "$c_bold" "$STEP_NO" "$1" "$c_0"
}
why() { printf '%s  why: %s%s\n' "$c_d" "$*" "$c_0"; }

die() { printf '\n%s FAILED %s %s\n\n' "$c_r" "$c_0" "$*"; exit 1; }

run() {
  if (( DRY )); then printf '  %s$ %s%s\n' "$c_y" "$*" "$c_0"; return 0; fi
  printf '  %s$ %s%s\n' "$c_d" "$*" "$c_0"
  "$@"
}

confirm() {   # confirm "question"  -> 0 yes / 1 no
  (( DRY )) && { info "[dry-run] would ask: $1"; return 0; }
  local a; read -rp "  $1 [y/N] " a
  [[ "$a" == [yY] ]]
}

require_confirm() { confirm "$1" || die "stopped at your request"; }

# ----------------------------------------------------------------- helpers ---
has()    { pacman -Qq 2>/dev/null | grep -qx "$1"; }
aurhelp() { for h in paru yay; do command -v "$h" >/dev/null && { echo "$h"; return; }; done; }

pysite() { python -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])' 2>/dev/null; }
tlspath() { echo "$(pysite)/proto9x/tls.py"; }

sensor_present() { lsusb 2>/dev/null | grep -qi "$SENSOR_ID"; }

backup_file() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  (( DRY )) && { info "[dry-run] would back up $f"; return 0; }
  mkdir -p "$BACKUP_DIR"
  sudo cp -a "$f" "$BACKUP_DIR/$(echo "${f#/}" | tr / _)" && info "backed up $f"
}

# =============================================================== STATUS ======
print_status() {
  printf '\n%s%s  FINGERPRINT STATUS%s\n' "$c_b" "$c_bold" "$c_0"
  sensor_present && ok "sensor present: $(lsusb | grep -i "$SENSOR_ID")" \
                 || bad "sensor NOT on the USB bus"
  has libfprint-vfs009x-git && ok "libfprint-vfs009x-git installed" \
                            || bad "libfprint-vfs009x-git missing (the patched driver)"
  has fprintd && ok "fprintd installed" || bad "fprintd missing"
  has validity-sensors-tools-git && ok "validity-sensors-tools-git installed" \
                                 || warn "validity-sensors-tools-git missing (needed to pair)"
  for p in python-validity open-fprintd fprintd-clients; do
    has "$p" && bad "$p installed — conflicts with this stack, remove it"
  done

  local t; t="$(tlspath)"
  if [[ -f "$t" ]]; then
    if grep -q 'sign(hexlify(buf).decode()' "$t"; then
      bad "proto9x is UNPATCHED — pairing will fail (run with --patch-only)"
    elif grep -q 'sign(buf, self.priv_key, prehashed=True)' "$t"; then
      ok "proto9x patch present"
    else
      warn "proto9x present but the sign() line looks unfamiliar — inspect $t"
    fi
  fi

  if command -v tlp-stat >/dev/null; then
    if sudo -n tlp-stat -u 2>/dev/null | grep -q "$SENSOR_ID.*control = on"; then
      ok "TLP autosuspend disabled for the sensor"
    else
      warn "TLP may be autosuspending the sensor (needs sudo to confirm)"
    fi
  fi

  fprintd-list "$USER" 2>/dev/null | grep -q '#' \
    && ok "fingerprint enrolled: $(fprintd-list "$USER" 2>/dev/null | grep '#' | tr -d '\n')" \
    || warn "no fingerprint enrolled yet"

  grep -qs pam_fprintd /etc/pam.d/sudo     && ok "PAM: sudo wired"     || warn "PAM: sudo not wired"
  grep -qs pam_fprintd /etc/pam.d/polkit-1 && ok "PAM: polkit wired"   || warn "PAM: polkit not wired"
  [[ -f /etc/pam.d/hyprlock ]] && grep -q faillock /etc/pam.d/hyprlock \
    && warn "hyprlock PAM still uses faillock — successful finger unlocks will lock your password"
  printf '\n'
}

(( STATUS_ONLY )) && { print_status; exit 0; }

# ================================================================ PATCH ======
apply_proto9x_patch() {
  local t; t="$(tlspath)"
  [[ -f "$t" ]] || die "proto9x not found at $t — is validity-sensors-tools-git installed?"

  if grep -q 'sign(buf, self.priv_key, prehashed=True)' "$t"; then
    ok "patch already applied"
    return 0
  fi
  if ! grep -q 'sign(hexlify(buf).decode(), self.priv_key, prehashed=True)' "$t"; then
    warn "the expected line was not found in $t"
    info "upstream may have fixed this. Look for make_cert_verify() and check"
    info "whether sign() is passed bytes rather than a hex string."
    return 1
  fi

  backup_file "$t"
  run sudo sed -i \
    's/sign(hexlify(buf)\.decode(), self\.priv_key, prehashed=True)/sign(buf, self.priv_key, prehashed=True)/' \
    "$t"
  (( DRY )) && return 0
  grep -q 'sign(buf, self.priv_key, prehashed=True)' "$t" \
    && ok "patched $t" || die "patch did not take"
}

if (( PATCH_ONLY )); then
  printf '\n%sRe-applying the proto9x patch only.%s\n' "$c_bold" "$c_0"
  why "any rebuild of validity-sensors-tools-git overwrites /usr/lib/..., reverting it"
  apply_proto9x_patch
  exit 0
fi

# ============================================================== PREAMBLE =====
cat <<EOF

${c_bold}ThinkPad P50 fingerprint setup${c_0}
$( (( DRY )) && echo "${c_y}DRY RUN — nothing will be changed${c_0}" )

This will take about 15 minutes and requires one reboot into the BIOS.
Backups of every file touched go to:
    $BACKUP_DIR

EOF

[[ $EUID -eq 0 ]] && die "do not run this as root — run it as your normal user; it calls sudo itself"
command -v pacman >/dev/null || die "this script is for Arch / CachyOS"

require_confirm "Do you have a root shell open on another TTY (Ctrl+Alt+F2)?"

# ============================================================== STEP 1 =======
step "Identify the sensor"
why "the P50 shipped Validity 138a:0090; every other sensor needs a different driver,
       and picking the wrong one wastes hours"

if sensor_present; then
  ok "found: $(lsusb | grep -i "$SENSOR_ID")"
else
  bad "no $SENSOR_ID on the USB bus"
  lsusb | grep -iE '138a|06cb|04f3|27c6|1c7a' || info "no known fingerprint vendor at all"
  cat <<'EOF'
    Before assuming the hardware is dead:
      * BIOS (F1) -> Security -> I/O Port Access -> Fingerprint Reader = Enabled
      * sudo dmesg | grep -iE '138a|xhci.*reset'
        repeated "reset full-speed USB device" = present but the driver can't talk to it
      * the reader is a separate FRU (board + ribbon cable). Some P50s shipped
        without one, and it is easy to leave unseated after a keyboard swap.
    If your sensor is a DIFFERENT id, stop — this script is wrong for it.
EOF
  die "sensor not found"
fi

# ============================================================== STEP 2 =======
step "Remove conflicting fingerprint stacks"
why "fprintd and open-fprintd claim the SAME D-Bus name (net.reactivated.Fprint)
       and install the same files. With both present a random one wins and nothing works"

CONFLICTS=()
for p in python-validity python-validity-git open-fprintd open-fprintd-git \
         fprintd-clients libfprint-vfs0090-git; do
  has "$p" && CONFLICTS+=("$p")
done

if (( ${#CONFLICTS[@]} )); then
  warn "found: ${CONFLICTS[*]}"
  if confirm "Remove them?"; then
    run sudo systemctl disable --now python3-validity python3-validity-suspend-hotfix \
        open-fprintd open-fprintd-suspend open-fprintd-resume 2>/dev/null
    run sudo systemctl reset-failed
    AUR="$(aurhelp)"
    [[ -n "$AUR" ]] && run "$AUR" -Rns --noconfirm "${CONFLICTS[@]}" \
                    || run sudo pacman -Rns --noconfirm "${CONFLICTS[@]}"
    run sudo rm -rf /var/run/python-validity /etc/python-validity
    run sudo systemctl unmask fprintd
  fi
else
  ok "nothing conflicting installed"
fi

# ============================================================== STEP 3 =======
step "Install the driver stack"
why "upstream libfprint has never supported 138a:0090 — its device list jumps from
       138a:0018 to 138a:0050. libfprint-vfs009x-git is a fork that adds it"

AUR="$(aurhelp)"
[[ -n "$AUR" ]] || die "need an AUR helper (paru or yay) — install one first"
: "${AUR:=paru}"
info "using AUR helper: $AUR"

run sudo pacman -S --needed --noconfirm fprintd
has libfprint-vfs009x-git && ok "libfprint-vfs009x-git already installed" \
                          || run "$AUR" -S --needed libfprint-vfs009x-git
has validity-sensors-tools-git && ok "validity-sensors-tools-git already installed" \
                               || run "$AUR" -S --needed validity-sensors-tools-git

cat <<EOF
    ${c_d}Note: libfprint-vfs009x-git REPLACES system libfprint with a fork pinned to
    1.94.9, and pulls in openssl-1.1 (EOL 2023) from the AUR. That is the standing
    maintenance cost of this sensor. If the reader breaks after a system upgrade,
    the first thing to try is:  $AUR -S --rebuild libfprint-vfs009x-git${c_0}
EOF

# ============================================================== STEP 4 =======
step "Repair Python version drift"
why "AUR python packages install into the interpreter version current AT BUILD TIME.
       After Arch bumps python 3.x, their modules vanish and the tools die with
       ModuleNotFoundError. This finds and rebuilds every stranded package"

CURRENT_SITE="$(pysite)"
info "current interpreter site-packages: $CURRENT_SITE"

STRANDED=()
for d in /usr/lib/python3.*/site-packages; do
  [[ "$d" == "$CURRENT_SITE" ]] && continue
  [[ -d "$d" ]] || continue
  while IFS= read -r pkg; do
    [[ -n "$pkg" ]] && STRANDED+=("$pkg")
  done < <(pacman -Qoq "$d"/*/ 2>/dev/null | sort -u)
done

# de-duplicate
if (( ${#STRANDED[@]} )); then
  mapfile -t STRANDED < <(printf '%s\n' "${STRANDED[@]}" | sort -u)
  warn "stranded in an old python: ${STRANDED[*]}"
  info "these must be rebuilt or the pairing tool cannot import proto9x/fastecdsa"
  confirm "Rebuild them now?" && run "$AUR" -S --rebuild --noconfirm "${STRANDED[@]}"
else
  ok "no packages stranded in an old python version"
fi

# ============================================================== STEP 5 =======
step "Patch proto9x (the str/bytes bug)"
why "proto9x calls  sign(hexlify(buf).decode(), ...)  — a hex STRING. Current
       fastecdsa requires bytes when prehashed=True and raises
       'Prehashed message must be bytes'. Pairing then dies AFTER writing the
       flash partition table, leaving the sensor half-configured and the retry
       failing with 'Flash is already partitioned'.
       Passing raw digest bytes is byte-identical: fastecdsa hexlifies internally"

apply_proto9x_patch

# ============================================================== STEP 6 =======
step "Clear the sensor's flash from the BIOS"
why "the sensor stores pairing keys derived from the machine's DMI serial. An
       ex-corporate ThinkPad almost certainly has a previous owner's Windows
       enrollment still in there, which makes the driver fail the handshake with
       'protocol error'. Only the BIOS can wipe it — factory-reset over USB
       returns 0404 on this model"

cat <<'EOF'
    Reboot now and press F1 for ThinkPad Setup, then:

        Security -> Fingerprint -> Reset Fingerprints Data     <- the important one
        Security -> Fingerprint -> Predesktop Authentication = Off
        Security -> Fingerprint -> Security Mode = Normal

    Predesktop Auth off stops the BIOS competing for the sensor while we debug.
    Save, exit, log back in, and re-run this script — it will skip the steps
    already done and resume here.
EOF

require_confirm "Have you ALREADY done the BIOS reset (answer n to stop and do it now)?"

# ============================================================== STEP 7 =======
step "Pair the sensor with this machine"
why "with clean flash and patched code, the initializer downloads Lenovo's Windows
       driver, extracts the firmware blob, flashes it, generates pairing keys tied
       to this machine's DMI serial, and calibrates the sensor"

run sudo systemctl stop fprintd
info "this takes a minute and downloads ~50MB. Do not interrupt it — it writes flash."

if (( ! DRY )); then
  sudo /usr/bin/validity-sensors-tools -t initializer || {
    bad "initializer failed"
    cat <<'EOF'
    Common causes:
      "Flash is already partitioned"  -> a previous half-run. Redo the BIOS reset
                                         (step 6), then run this script again.
      "Prehashed message must be bytes" -> the patch did not apply. Run:
                                         bash fingerprint-setup.sh --patch-only
      "Failed: 0404" during factory reset -> harmless, the tool says so itself
                                         and continues.
EOF
    die "pairing failed"
  }
  ok "sensor paired"
fi

# calibration data lands in a temp dir that /tmp (tmpfs) loses on reboot
if (( ! DRY )); then
  CALIB="$(find /tmp -name 'calib-data.bin' -newermt '-10 minutes' 2>/dev/null | head -1)"
  if [[ -n "$CALIB" ]]; then
    mkdir -p "$HOME/fingerprint-setup-backups"
    cp "$CALIB" "$HOME/fingerprint-setup-backups/calib-data.bin" \
      && ok "saved calibration data -> ~/fingerprint-setup-backups/calib-data.bin"
    info "if you ever re-pair, pass it with:  -c ~/fingerprint-setup-backups/calib-data.bin"
  fi
fi

# ============================================================== STEP 8 =======
step "Stop TLP from suspending the sensor"
why "TLP autosuspends idle USB devices after 2s. This reader is driven from
       USERSPACE (usbfs), so an autosuspended device produces USB transfer
       timeouts and 'device disconnected' — and hyprlock treats a disconnect as
       permanent, disabling fingerprint for the whole lock session.
       This is the difference between 'works' and 'works for ten minutes'"

if has tlp; then
  backup_file /etc/tlp.d/30-fingerprint.conf
  if (( DRY )); then
    info "[dry-run] would write /etc/tlp.d/30-fingerprint.conf with USB_DENYLIST=\"$SENSOR_ID\""
  else
    sudo tee /etc/tlp.d/30-fingerprint.conf >/dev/null <<EOF
# Validity VFS7500 — userspace (usbfs) driver. Autosuspend causes USB transfer
# timeouts and spurious disconnects during fprintd claims.
USB_DENYLIST="$SENSOR_ID"
EOF
    ok "wrote /etc/tlp.d/30-fingerprint.conf"
    run sudo tlp start
    sudo tlp-stat -u 2>/dev/null | grep "$SENSOR_ID" | sed 's/^/    /'
  fi
else
  info "TLP not installed — nothing to do (but if you install it later, re-run this step)"
fi

# ============================================================== STEP 9 =======
step "Enroll a fingerprint"
why "enrollment is per-user and stored on the sensor. Run as YOU, never as root"

run sudo systemctl start fprintd
if (( ! DRY )); then
  echo
  info "Place the pad of your finger flat, cover the whole sensor, hold ~1s, lift."
  info "It is a TOUCH sensor — do not swipe, despite what the messages say."
  info "Shift position slightly between touches so it captures the edges."
  info "Expect to need a few attempts; 'enroll-unknown-error' means start over."
  echo
  if fprintd-list "$USER" 2>/dev/null | grep -q '#'; then
    ok "already enrolled: $(fprintd-list "$USER" | grep '#')"
    confirm "Re-enroll from scratch?" && { fprintd-delete "$USER"; fprintd-enroll -f right-index-finger; }
  else
    until fprintd-enroll -f right-index-finger; do
      confirm "Enrollment failed. Try again?" || break
    done
  fi
  confirm "Enroll a second finger (recommended — a cut or bandage otherwise costs you a week)?" \
    && fprintd-enroll -f left-index-finger
fi

# ============================================================= STEP 10 =======
step "Verify — including across suspend"
why "this sensor family's signature failure is working perfectly until the first
       suspend and then going silent. Finding that out at a lock screen is worse"

if (( ! DRY )); then
  for i in 1 2 3; do
    echo "    verification $i of 3:"
    fprintd-verify || warn "no match — try again"
  done
  echo
  info "Now: systemctl suspend, resume, then run 'fprintd-verify' once more."
  info "Do NOT wire up PAM until that passes."
  confirm "Has verification succeeded repeatedly AND after a suspend/resume?" \
    || die "stop here. PAM on an unreliable sensor is how you get locked out."
fi

# ============================================================= STEP 11 =======
step "Wire fingerprint into sudo and polkit"
why "'sufficient' means: finger succeeds -> done; finger fails or is absent ->
       falls through to the password. Never 'required'. timeout=10 instead of the
       30s default is the single biggest usability fix — otherwise sudo looks hung"

PAM_LINE='auth      sufficient  pam_fprintd.so timeout=10 max-tries=2'

# --- sudo ---
if grep -q '^[^#]*pam_fprintd' /etc/pam.d/sudo 2>/dev/null; then
  ok "/etc/pam.d/sudo already wired"
else
  backup_file /etc/pam.d/sudo
  run sudo sed -i "0,/^auth/s//$PAM_LINE\nauth/" /etc/pam.d/sudo
  (( DRY )) || ok "patched /etc/pam.d/sudo"
  cat <<'EOF'

    TEST IT NOW, from a different terminal:
        sudo -k && sudo -v
    It should ask for a finger, and still accept your password if you ignore it.
    If it hangs or refuses, from your root TTY:
        sed -i '/pam_fprintd/d' /etc/pam.d/sudo
EOF
  confirm "Did sudo still work?" || {
    run sudo sed -i '/pam_fprintd/d' /etc/pam.d/sudo
    die "reverted the sudo change — investigate before retrying"
  }
fi

# --- polkit (lives in the vendor dir now; copy before editing) ---
if [[ ! -f /etc/pam.d/polkit-1 && -f /usr/lib/pam.d/polkit-1 ]]; then
  why "polkit moved to /usr/lib/pam.d. /etc/pam.d overrides same-named files there,
       so we copy rather than edit the packaged one"
  run sudo cp /usr/lib/pam.d/polkit-1 /etc/pam.d/polkit-1
fi
if [[ -f /etc/pam.d/polkit-1 ]] && ! grep -q '^[^#]*pam_fprintd' /etc/pam.d/polkit-1; then
  backup_file /etc/pam.d/polkit-1
  run sudo sed -i "0,/^auth/s//$PAM_LINE\nauth/" /etc/pam.d/polkit-1
  (( DRY )) || ok "patched /etc/pam.d/polkit-1  (test: pkexec true)"
fi

# ============================================================= STEP 12 =======
step "Give hyprlock its own PAM stack (no faillock)"
why "hyprlock runs fingerprint and PAM concurrently. When the finger wins it
       ABORTS the in-flight PAM conversation, and pam_faillock counts that as a
       failed login. Default deny=3 means roughly every third SUCCESSFUL unlock
       locks your password for 10 minutes — while the lock screen is up"

if [[ -f /etc/pam.d/hyprlock ]] && ! grep -q faillock /etc/pam.d/hyprlock \
   && grep -q 'pam_unix.so' /etc/pam.d/hyprlock; then
  ok "hyprlock already has a standalone stack"
elif command -v hyprlock >/dev/null; then
  info "Arch's default is 'auth include login', which pulls in faillock."
  if confirm "Replace /etc/pam.d/hyprlock with a faillock-free stack?"; then
    backup_file /etc/pam.d/hyprlock
    if (( ! DRY )); then
      sudo tee /etc/pam.d/hyprlock >/dev/null <<'EOF'
#%PAM-1.0
# Standalone stack with no pam_faillock: hyprlock's aborted PAM thread (when
# fingerprint auth wins) otherwise registers as a failed login and locks the
# password fallback. On a lock screen faillock protects against nothing an
# attacker holding the laptop cannot already bypass.
auth      required   pam_unix.so
account   required   pam_unix.so
session   required   pam_unix.so
EOF
      ok "wrote /etc/pam.d/hyprlock"
      warn "TEST BY TYPING YOUR PASSWORD at the lock screen before trusting it"
      info "rollback:  sudo cp $BACKUP_DIR/etc_pam.d_hyprlock /etc/pam.d/hyprlock"
    fi
  fi
  cat <<'EOF'

    Then add this to ~/.config/hypr/hyprlock.conf (hyprlock talks to fprintd over
    D-Bus directly — do NOT add pam_fprintd to /etc/pam.d/hyprlock, it only hangs):

        auth {
            pam { enabled = true; module = hyprlock }
            fingerprint {
                enabled = true
                ready_message = Scan fingerprint or type password
                present_message = Scanning fingerprint
                retry_delay = 1500
            }
        }

    retry_delay is deliberately long: hyprlock allows only 3 retries (hardcoded,
    not configurable) before disabling fingerprint for that lock session, and the
    250ms default burns all three before you can reposition your finger.
EOF
else
  info "hyprlock not installed — skipping"
fi

# ============================================================= WRAP UP =======
step "Done"
print_status

cat <<EOF
${c_bold}Standing maintenance — this stack is not fire-and-forget:${c_0}

  After a python minor version bump (3.14 -> 3.15):
      bash $0 --status        # will flag stranded packages
      $AUR -S --rebuild validity-sensors-tools-git python-fastecdsa

  After ANY rebuild of validity-sensors-tools-git:
      bash $0 --patch-only    # the proto9x patch lives in /usr/lib and gets reverted

  After a libfprint or glib2 upgrade, if the reader stops working:
      $AUR -S --rebuild libfprint-vfs009x-git

  After pambase / sudo / polkit updates:
      pacdiff -s              # re-merge your pam_fprintd lines from .pacnew files

  If sudo suddenly demands a password every time and rejects it:
      faillock --user "\$USER"          # check the tally
      faillock --user "\$USER" --reset

${c_bold}Backups from this run:${c_0} $BACKUP_DIR

${c_bold}Honest assessment:${c_0} this is a 2016 sensor with no upstream support, held
together by a libfprint fork pinned to an old release and an EOL openssl. It works,
and it survives suspend once TLP is told to leave it alone — but budget a rebuild
every few months. If it ever costs more than it saves, remove the two pam_fprintd
lines and you are back to passwords with nothing else broken.
EOF
