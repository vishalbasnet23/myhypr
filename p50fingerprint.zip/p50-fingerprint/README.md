# ThinkPad P50 — Fingerprint Reader on Linux

Everything needed to get the Validity **VFS7500 (`138a:0090`)** working on a fresh
CachyOS / Arch install, and to keep it working.

Written against a Lenovo ThinkPad P50 (20EQS37300), CachyOS, kernel 7.1.x,
Hyprland + hyprlock, SDDM. August 2026.

---

## Quick start

```bash
chmod +x fingerprint-setup.sh
bash fingerprint-setup.sh --status     # what's the current state?
bash fingerprint-setup.sh              # guided run, ~15 min + one BIOS reboot
```

Run it **as your normal user, never under sudo** — it calls sudo where needed.
Running the whole thing as root enrolls the fingerprint against root instead of you.

Open a root shell on another TTY first (`Ctrl+Alt+F2` → log in → `sudo -i`) and
leave it there. That's your undo channel if a PAM edit goes wrong.

---

## Why this is harder than it looks

Three things trip up nearly everyone, and none are obvious from the error messages.

### 1. Upstream libfprint does not support this sensor

The [supported-devices list](https://fprint.freedesktop.org/supported-devices.html)
covers `138a: 0001 0005 0008 0010 0011 0015 0017 0018 0050 0091`. **`0090` is absent**,
and always has been. The mature `synaptics` driver targets a completely different
generation (`06cb:00bd` and up, T14s-era match-on-chip sensors).

So `pacman -S fprintd` alone gets you nothing. You need the patched fork
**`libfprint-vfs009x-git`**.

Most guides point at **python-validity** instead. Don't: it recognises `138a:0090`
but its enrollment failures on that exact chip have been open
[since 2021](https://github.com/uunicorn/python-validity/issues/71).

### 2. proto9x has a str/bytes bug that modern fastecdsa rejects

`proto9x/tls.py` contains:

```python
s = sign(hexlify(buf).decode(), self.priv_key, prehashed=True)   # a hex STRING
```

Current fastecdsa requires **bytes** when `prehashed=True` and raises
`Prehashed message must be bytes, got <class 'str'>`.

The damage is worse than a clean failure: pairing dies *after* `partition_flash()`
has already written the partition table, so every retry then fails with
**`Flash is already partitioned`** — and only a BIOS reset can clear it.

The fix is to pass the raw digest and let the library hex it, which produces a
byte-identical signature (fastecdsa's `_hex_digest()` does `hexlify(msg).decode()`
internally). See `reference/proto9x-tls.patch`.

### 3. TLP autosuspends the sensor into unreliability

TLP powers down idle USB devices after 2 seconds. This reader is driven from
**userspace** (`usbfs`), so an autosuspended device produces:

```
fprintd: USB write transfer error: transfer timed out
fprintd: Data exchange failed at state 1, usb error: transfer timed out
kernel:  usb 1-9: reset full-speed USB device number 5 using xhci_hcd
```

And hyprlock treats `MATCH_DISCONNECTED` as **permanent** — it sets `abort = true`
and never retries, disabling fingerprint for the rest of that lock session.

This is the difference between "works" and "works for ten minutes". Fix:
`reference/30-fingerprint.conf`.

---

## What the script does

| # | Step | Notes |
|---|------|-------|
| 1 | Identify the sensor | Refuses to continue on any other USB ID |
| 2 | Remove conflicting stacks | `fprintd` and `open-fprintd` claim the same D-Bus name |
| 3 | Install driver | repo `fprintd` + `libfprint-vfs009x-git` + `validity-sensors-tools-git` |
| 4 | Repair Python drift | Finds packages stranded in an old `site-packages`, rebuilds them |
| 5 | Patch proto9x | Idempotent; only fires if the old line is present |
| 6 | BIOS reset | Stops and waits — nothing else can clear stale pairing keys |
| 7 | Pair the sensor | Runs `-t initializer`, rescues `calib-data.bin` from tmpfs |
| 8 | TLP denylist | Skipped if TLP isn't installed |
| 9 | Enroll | Touch-don't-swipe guidance, retry loop |
| 10 | Verify incl. suspend | **Refuses to proceed to PAM** unless suspend/resume passes |
| 11 | sudo + polkit | Mandatory "did sudo still work?" checkpoint, auto-reverts on no |
| 12 | hyprlock PAM stack | Removes faillock; prints the hyprlock config block |

Every file it touches is backed up to `~/fingerprint-setup-backups/<timestamp>/`,
with the rollback command printed inline.

---

## Manual procedure

If the script fails or you'd rather drive it yourself:

```bash
# 1. confirm the sensor
lsusb | grep 138a:0090

# 2. driver stack
sudo pacman -S --needed fprintd
paru -S libfprint-vfs009x-git validity-sensors-tools-git

# 3. rebuild anything stranded in an old python
pacman -Qoq /usr/lib/python3.13/site-packages/*/ 2>/dev/null | sort -u
paru -S --rebuild python-fastecdsa validity-sensors-tools-git

# 4. patch proto9x
PYSITE=$(python -c 'import sysconfig;print(sysconfig.get_paths()["purelib"])')
sudo cp "$PYSITE/proto9x/tls.py"{,.bak}
sudo sed -i 's/sign(hexlify(buf)\.decode(), self\.priv_key, prehashed=True)/sign(buf, self.priv_key, prehashed=True)/' \
  "$PYSITE/proto9x/tls.py"

# 5. BIOS: F1 -> Security -> Fingerprint -> Reset Fingerprints Data
#         Predesktop Authentication = Off, Security Mode = Normal

# 6. pair
sudo systemctl stop fprintd
sudo /usr/bin/validity-sensors-tools -t initializer

# 7. stop TLP suspending it
sudo cp reference/30-fingerprint.conf /etc/tlp.d/
sudo tlp start

# 8. enroll and verify — as your user, no sudo
sudo systemctl start fprintd
fprintd-enroll -f right-index-finger
fprintd-verify            # repeat, then suspend/resume and repeat again

# 9. PAM — root shell open on TTY2 first
#    see reference/pam.d-sudo.snippet and reference/pam.d-hyprlock
```

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `failed to claim device: protocol error` | Stale pairing keys from a previous Windows enrollment | BIOS → Reset Fingerprints Data |
| `Prehashed message must be bytes` | proto9x unpatched | `bash fingerprint-setup.sh --patch-only` |
| `Flash is already partitioned` | Pairing died mid-run and left the partition table written | BIOS reset, then re-run the initializer |
| `ModuleNotFoundError: No module named 'proto9x'` (or `fastecdsa`) | Python minor bump stranded the AUR package | `paru -S --rebuild <pkg>` |
| `Failed: 0404` during factory reset | Expected on this model | Ignore — the tool says so and continues |
| `No devices available` from `fprintd-list` | Sensor wiped but not yet paired | Run the initializer |
| USB transfer timeouts, random disconnects | TLP autosuspend | `reference/30-fingerprint.conf` |
| `enroll-unknown-error` | Poor capture; aborts the whole enrollment | `fprintd-delete "$USER"` then re-enroll. Touch, don't swipe |
| Works, then dies after suspend | Autosuspend, or the sensor was never re-claimed | Check the TLP denylist is active |
| sudo demands password and rejects it | pam_faillock counted aborted PAM threads as failures | `faillock --user "$USER" --reset` + `reference/pam.d-hyprlock` |
| Fingerprint stops working mid-lock-session | hyprlock's hardcoded 3-retry cap, or `MATCH_DISCONNECTED` | Unlock with password, re-lock. Raise `retry_delay` |

Useful diagnostics:

```bash
sudo systemctl stop fprintd
sudo G_MESSAGES_DEBUG=all /usr/lib/fprintd -t     # then run fprintd-enroll elsewhere
journalctl -u fprintd -b --no-pager | tail -40
sudo dmesg | grep -iE '138a|xhci.*reset' | tail -20
sudo tlp-stat -u | grep 138a
busctl --system list | grep -i fprint             # exactly ONE owner expected
```

---

## Maintenance

This stack is not fire-and-forget. Budget a rebuild every few months.

| Trigger | Action |
|---|---|
| Python minor bump (3.14 → 3.15) | `paru -S --rebuild validity-sensors-tools-git python-fastecdsa` |
| Any rebuild of `validity-sensors-tools-git` | `bash fingerprint-setup.sh --patch-only` — the patch lives in `/usr/lib` and gets reverted |
| libfprint / glib2 upgrade breaks the reader | `paru -S --rebuild libfprint-vfs009x-git` |
| `pambase` / `sudo` / `polkit` / `hyprlock` updates | `pacdiff -s`, re-merge your `pam_fprintd` lines |
| Reader mysteriously unreliable again | Check TLP didn't reset the denylist: `sudo tlp-stat -u \| grep 138a` |

`bash fingerprint-setup.sh --status` checks most of this in one shot.

---

## Security notes

Worth being clear-eyed about what this does and doesn't give you.

- **Consumer fingerprint sensors are a convenience factor, not a strong auth
  factor.** Blackwing Intelligence
  [bypassed Windows Hello](https://blackwinghq.com/blog/posts/a-touch-of-pwn-part-i/)
  on a Synaptics ThinkPad sensor via USB spoofing. None of these Linux drivers
  implement SDCP at all.
- `pam_fprintd` is wired as **`sufficient`**, never `required` — a dead sensor
  falls through to your password rather than locking you out.
- The hyprlock PAM stack here **removes faillock**. On a lock screen that protects
  against nothing an attacker holding the laptop can't already bypass, and leaving
  it in means successful fingerprint unlocks lock your own password every third try.
- **Never** put `pam_fprintd` anywhere in the sshd path.
- `libfprint-vfs009x-git` pulls in **openssl-1.1**, EOL since September 2023.
  That's a real, standing tradeoff for using this sensor at all.

---

## Files

```
fingerprint-setup.sh              the whole thing, guided
reference/
  proto9x-tls.patch               the str/bytes fix as a diff
  30-fingerprint.conf             TLP USB denylist
  pam.d-sudo.snippet              the sudo/polkit auth line
  pam.d-hyprlock                  faillock-free lock screen stack
  hyprlock-auth.conf              hyprlock auth block
```

---

## Sources

- [libfprint supported devices](https://fprint.freedesktop.org/supported-devices.html)
- [3v1n0/libfprint vfs0090](https://github.com/3v1n0/libfprint/blob/vfs0090/README.md) ·
  [issue #48 — str/bytes in sign()](https://github.com/3v1n0/libfprint/issues/48) ·
  [issue #41 — flash already partitioned](https://github.com/3v1n0/libfprint/issues/41)
- [proto9x/tls.py](https://raw.githubusercontent.com/3v1n0/python-validity/master/proto9x/tls.py) ·
  [init_flash.py](https://raw.githubusercontent.com/3v1n0/python-validity/master/proto9x/init_flash.py)
- [fastecdsa ecdsa.py](https://raw.githubusercontent.com/AntonKueltz/fastecdsa/master/fastecdsa/ecdsa.py)
- [uunicorn/python-validity](https://github.com/uunicorn/python-validity)
- [Gentoo Wiki: ThinkPad P50](https://wiki.gentoo.org/wiki/Lenovo_ThinkPad_P50) ·
  [ThinkWiki: fingerprint readers](https://www.thinkwiki.org/wiki/Integrated_Fingerprint_Reader)
- [Lenovo BIOS fingerprint settings](https://docs.lenovocdrt.com/ref/bios/settings/thinkpad/fingerprint/)
- [Arch BBS: 138a:0090 solved](https://bbs.archlinux.org/viewtopic.php?id=307473)
- [pam_fprintd(8)](https://man.archlinux.org/man/pam_fprintd.8) ·
  [faillock(8)](https://man.archlinux.org/man/faillock.8)
- hyprlock: [#608](https://github.com/hyprwm/hyprlock/issues/608) ·
  [#702](https://github.com/hyprwm/hyprlock/issues/702) ·
  [#768](https://github.com/hyprwm/hyprlock/issues/768) ·
  [Fingerprint.cpp](https://raw.githubusercontent.com/hyprwm/hyprlock/main/src/auth/Fingerprint.cpp)
- [TLP USB settings](https://linrunner.de/tlp/settings/usb.html)
